package com.example.hashem.notiapp;

public class IpAddress {
    private String ip;

    public IpAddress() {
        this.ip = "http://192.168.0.48/notiApp/";
    }

    public String getIp() {
        return ip;
    }
}
