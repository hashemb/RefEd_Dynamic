package com.example.hashem.notiapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;

import static android.content.ContentValues.TAG;

public class RegistrationActivity extends Activity {

    EditText et;
    Button btn;
    String token;
    IpAddress ip = new IpAddress();
    String url = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);


        SharedPreferences myPrefs;
        myPrefs = getSharedPreferences("registered", MODE_PRIVATE);
        String StoredValue = myPrefs.getString("registered", "");
        if (StoredValue.equals("1")) {
            Intent i = new Intent(RegistrationActivity.this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
        } else {
            et = findViewById(R.id.editText);
            btn = findViewById(R.id.button);

            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    String name = et.getText().toString();
                    if (name.equals(""))
                        Toast.makeText(RegistrationActivity.this, "Type your name please", Toast.LENGTH_SHORT).show();
                    else {
                        register(name);
                    }
                }
            });
        }
    }
        public void register (String name){
            final String n = name;
            FirebaseInstanceId.getInstance().getInstanceId()
                    .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                        @Override
                        public void onComplete(@NonNull Task<InstanceIdResult> task) {
                            if (!task.isSuccessful()) {
                                Log.w(TAG, "getInstanceId failed", task.getException());
                                return;
                            }
                            // Get new Instance ID token
                            Log.d("Hi", "Getting token");
                            token = task.getResult().getToken();
                            Log.d("GOT THE TOKEN:", token);
                            url = ip.getIp() + "registration.php?regid=" + token + "&name=" + n;
                            RequestQueue queue = Volley.newRequestQueue(RegistrationActivity.this);
                            StringRequest jsonRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    try {
                                        JSONObject result = new JSONObject(response);
                                        String x = result.get("result").toString();
                                        if (x.equals("false")) {
                                            Toast.makeText(RegistrationActivity.this, "Failed to register", Toast.LENGTH_SHORT).show();
                                        } else {
                                            Toast.makeText(RegistrationActivity.this, "Registered Successfully", Toast.LENGTH_SHORT).show();
                                        }


                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                                    , new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    error.printStackTrace();

                                    // Toast.makeText(RegistrationActivity.this, "ERROR", Toast.LENGTH_SHORT).show();

                                }
                            });

                            queue.add(jsonRequest);

                            Intent i = new Intent(RegistrationActivity.this, MainActivity.class);
                            startActivity(i);
                        }
                    });
        }

}