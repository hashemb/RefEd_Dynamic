package com.example.hashem.notiapp;

import android.content.Context;
import android.util.Log;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;

import java.util.List;

import static android.content.ContentValues.TAG;

public class Refresh extends Thread {
    ListView listView;
    Context context;
    String ip;
    String token;
    SwipeRefreshLayout s;


    public Refresh(ListView listView, Context context, String ip, String token, SwipeRefreshLayout s) {
        this.listView = listView;
        this.context = context;
        this.ip = ip;
        this.token = token;
        this.s = s;
    }

    @Override
    public void run() {


        FirebaseInstanceId.getInstance().getInstanceId()
                .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                    @Override
                    public void onComplete(@NonNull Task<InstanceIdResult> task) {
                        if (!task.isSuccessful()) {
                            Log.w(TAG, "getInstanceId failed", task.getException());
                            return;
                        }
                        // Get new Instance ID token
                        Log.d("Hi", "Getting token");
                        token = task.getResult().getToken();
                        Log.d("Hi", token);
                        final Populate p = new Populate(ip, context,listView, token);
                        p.start();
                        if (s.isRefreshing()) {
                            s.setRefreshing(false);
                        }


                    }
                });

    }

}
