package com.example.hashem.notiapp;
import android.app.Activity;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Notification;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
public class NotificationActivity extends Activity {
    TextView t1;
    TextView t2;
    TextView t3;
    TextView t4;
    TextView t5;
    NotificationData n;
    IpAddress ip = new IpAddress();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        t1 = (TextView) findViewById(R.id.detid);
        t2 = (TextView) findViewById(R.id.dettitle);
        t3 = (TextView) findViewById(R.id.dettext);
        t4 = (TextView) findViewById(R.id.detdate);
        t5 = (TextView) findViewById(R.id.detrn);

        String id="";
        String title="";
        String text="";
        String date="";
        String rn="";

        Intent i = getIntent();
        if(i.getExtras().containsKey("id")){

            if(i.getExtras().get("from").toString().compareTo("app") == 0) {
                 id = i.getExtras().get("id").toString();
                 title = i.getExtras().get("title").toString();
                 text = i.getExtras().get("text").toString();
                 date = i.getExtras().get("date").toString();
                 rn = i.getExtras().get("rn").toString();
                 //t2.setText("HHDF");

                date = date.substring(0, 25);

                t1.setText(id);
                t2.setText(title);
                t3.setText(text);
                t4.setText(date);
                t5.setText(rn);


            }
            else if(i.getExtras().get("from").toString().compareTo("not") == 0) {

                id = i.getExtras().get("id").toString();
                //title = i.getExtras().get("title").toString();


                String url = ip.getIp() + "getNotification.php?id=" + id;
                //Toast.makeText(NotificationActivity.class, id, Toast.LENGTH_SHORT).show();

                RequestQueue queue = Volley.newRequestQueue(this);
                StringRequest jsonRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            //Toast.makeText(NotificationActivity.this, "AM HERER NOW", Toast.LENGTH_SHORT).show();
                            JSONObject not = new JSONObject(response);
                            n = new NotificationData(Integer.parseInt(not.getString("id")), not.getString("text"), not.getString("title"), not.getString("rn"), not.getString("date"));

                            t1.setText(String.valueOf(n.getId()));
                            t2.setText(n.getTitle());
                            t3.setText(n.getText());
                            t4.setText(n.getDate().substring(0,25));
                            t5.setText(n.getRn());

                            //Toast.makeText(NotificationActivity.this, n.toString(), Toast.LENGTH_SHORT).show();


                                } catch (JSONException e) {
                                }
                            }

                        }


                        , new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(NotificationActivity.this, "ERROR", Toast.LENGTH_SHORT).show();
                    }
                });
                queue.add(jsonRequest);
            }




        }

    }
}
