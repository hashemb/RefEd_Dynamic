package com.example.hashem.notiapp;

public class NotificationData {
     private int id;
     private String text;
     private String title;
     private String rn;
     private String date;


     public NotificationData(int id, String text, String title, String rn, String date) {
          this.id = id;
          this.text = text;
          this.title = title;
          this.rn = rn;
          this.date = date;
     }

     @Override
     public String toString() {
          return "NotificationData{" +
                  "id=" + id +
                  ", text='" + text + '\'' +
                  ", title='" + title + '\'' +
                  ", rn='" + rn + '\'' +
                  ", date='" + date + '\'' +
                  '}';
     }

     public String getRn() {
          return rn;
     }

     public void setRn(String rn) {
          this.rn = rn;
     }

     public int getId() {
          return id;
     }

     public void setId(int id) {
          this.id = id;
     }

     public String getText() {
          return text;
     }

     public void setText(String text) {
          this.text = text;
     }

     public String getTitle() {
          return title;
     }

     public void setTitle(String title) {
          this.title = title;
     }

     public String getDate() {
          return date;
     }

     public void setDate(String date) {
          this.date = date;
     }



}
