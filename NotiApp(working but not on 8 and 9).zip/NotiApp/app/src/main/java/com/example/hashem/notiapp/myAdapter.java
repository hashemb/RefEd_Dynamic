package com.example.hashem.notiapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nullable;

public class myAdapter extends ArrayAdapter<NotificationData> {


    private Context mContext;
    private List<NotificationData> nots;


    public myAdapter(ArrayList<NotificationData> data, Context context) {
        super(context, R.layout.listitem, data);
        this.nots = data;
        this.mContext=context;

    }
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItem = convertView;
        if(listItem == null)
            listItem = LayoutInflater.from(mContext).inflate(R.layout.listitem,parent,false);

        NotificationData not = nots.get(position);

        TextView t1 = (TextView)listItem.findViewById(R.id.textview);
        t1.setText(not.getText());

        TextView t2 = (TextView) listItem.findViewById(R.id.dateview);
        String edited = not.getDate().substring(0,25);
        t2.setText(edited);

        TextView t3 = (TextView) listItem.findViewById(R.id.titleview);
        t3.setText(not.getTitle());


        TextView t4 = (TextView) listItem.findViewById(R.id.codeview);
        t4.setText(not.getRn());


        TextView t5 = (TextView) listItem.findViewById(R.id.idview);
        t5.setText(String.valueOf(not.getId()));

        return listItem;
    }


}
