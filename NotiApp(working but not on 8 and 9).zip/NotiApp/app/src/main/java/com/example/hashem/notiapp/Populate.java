package com.example.hashem.notiapp;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;

import static android.content.ContentValues.TAG;

public class Populate extends Thread{
    private String ip;
    private String url;
    private String token;
    private Context context;
    private ListView listView;
    private static myAdapter adapter;
    private ArrayList<NotificationData> nots = new ArrayList<>();

    public Populate(String ip,  Context context, ListView listView, String token){
        this.ip = ip;
        this.context = context;
        this.listView = listView;
        this.token = token;
    }

    @Override
    public void run() {
        super.run();


        this.url = ip + "getNotifications.php?regid=" + token;
        //url = ip + "/notiApp/getNotifications.php?regid=eNvS29iOjjk:APA91bGinIXJ2-MTfTpg3WG5Fy6ayMR7n-umrCNplhfuevp7RgN_-Lt2ygIZrj4MKTNom2zDB2AgiLdkkmGAPVeG-AKnKJmCYz96_SzEnHGEAVTB8Pn5WqVtbgZQ2mm3pMoLe4qXuwr0";
        Log.d("NEW DEBUGGINNG", url);
        RequestQueue queue = Volley.newRequestQueue(this.context);
        StringRequest jsonRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray jArray = new JSONArray(response);
                    for (int k = 0; k < jArray.length(); k++) {
                        try {
                            JSONObject not = jArray.getJSONObject(k);
                            nots.add(new NotificationData(Integer.parseInt(not.getString("id")), not.getString("text"), not.getString("title"), not.getString("rn"), not.getString("date")));
                            //Toast.makeText(sectionsActivity.this, sections[0].toString(), Toast.LENGTH_SHORT).show();
                        } catch (JSONException e) {
                        }
                    }
                    adapter = new myAdapter(nots, context);
                    listView.setAdapter(adapter);
                    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                            Intent intent = new Intent(context, NotificationActivity.class);
                            intent.putExtra("from", "app");
                            intent.putExtra("id", adapter.getItem(position).getId());
                            intent.putExtra("title", adapter.getItem(position).getTitle());
                            intent.putExtra("text", adapter.getItem(position).getText());
                            intent.putExtra("date", adapter.getItem(position).getDate());
                            intent.putExtra("rn", adapter.getItem(position).getRn());
                            //Toast.makeText(sectionsActivity.this, arrayAdapter.getItem(position).toString(), Toast.LENGTH_SHORT).show();
                            context.startActivity(intent);


                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
                , new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                if (null != error.networkResponse)
                {
                    Log.d(TAG + ": ", "Error Response code: " + error.networkResponse.statusCode);
                }
            }
        });

        queue.add(jsonRequest);
    }
}
