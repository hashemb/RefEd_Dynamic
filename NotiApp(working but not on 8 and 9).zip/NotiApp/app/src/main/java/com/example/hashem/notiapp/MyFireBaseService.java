package com.example.hashem.notiapp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import static android.content.ContentValues.TAG;

public class MyFireBaseService extends FirebaseMessagingService {

        @Override
        public void onMessageReceived(RemoteMessage remoteMessage) {
            super.onMessageReceived(remoteMessage);

            sendNotification(remoteMessage.getData().get("body"),remoteMessage.getData().get("title"), remoteMessage.getData().get("id"));

            Log.d("On Message Recieved", "From: " + remoteMessage.getFrom());

            // Check if message contains a data payload.
            if (remoteMessage.getData().size() > 0) {
                Log.d("On Message Recieved", "Message data payload: " + remoteMessage.getData());
            }

            // Check if message contains a notification payload.
            if (remoteMessage.getNotification() != null) {
                Log.d("On Message Recieved", "Message NotificationData Body: " + remoteMessage.getNotification().getBody());
            }


        }
    void sendNotification(String message, String title, String id) {

        Intent intent = new Intent(this, NotificationActivity.class);
        intent.putExtra("id", id);
        intent.putExtra("title", title);
        intent.putExtra("message", message);
        intent.putExtra("from", "not");


        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_ONE_SHOT);



        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this,"1")

                .setContentTitle(title).setSmallIcon(R.mipmap.ic_launcher)
                .setContentText(message).setContentIntent(pendingIntent).setChannelId("1")
                .setAutoCancel(true);

        NotificationManagerCompat notificationManager = (NotificationManagerCompat) getSystemService(Context.NOTIFICATION_SERVICE);



        NotificationCompat notification = notificationBuilder.build();
        notificationManager.notify(0, notification);

    }

        public static String getToken(Context context) {
            return context.getSharedPreferences("_", MODE_PRIVATE).getString("fb", "empty");

        }
    /**
     * Called if InstanceID token is updated. This may occur if the security of
     * the previous token had been compromised. Note that this is called when the InstanceID token
     * is initially generated so this is where you would retrieve the token.
     */
    @Override
    public void onNewToken(String token) {
        super.onNewToken(token);
        Log.d(TAG, "Refreshed token: " + token);

        // If you want to send messages to this application instance or
        // manage this apps subscriptions on the server side, send the
        // Instance ID token to your app server.

        //getSharedPreferences("_", MODE_PRIVATE).edit().putString("fb", s).apply();

        sendRegistrationToServer(token);

    }


    void sendRegistrationToServer(String token){

           // update token on the server
    }
}
