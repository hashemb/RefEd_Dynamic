package com.example.hashem.notiapp;
import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ListView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

public class MainActivity extends Activity{
    ListView listView;
    IpAddress ip = new IpAddress();
    String token = "";

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listNots);

        final SwipeRefreshLayout s = findViewById(R.id.swipe);

        SharedPreferences userDetails = MainActivity.this.getSharedPreferences("registered", MODE_PRIVATE);
        SharedPreferences.Editor edit = userDetails.edit();
        edit.putString("registered", "1");
        //edit.putString("password", password.getText().toString().trim());
        edit.apply();

        s.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                Refresh r = new Refresh(listView, MainActivity.this, ip.getIp(), token, s);
                r.start();
            }
        });




        Refresh r = new Refresh(listView, MainActivity.this, ip.getIp(), token, s);
        r.start();

    }
}
